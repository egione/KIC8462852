/*
Bitscan
Copyright 2017 Russell Leidich

This collection of files constitutes the Bitscan Library. (This is a
library in the abstact sense; it's not intended to compile to a ".lib"
file.)

The Bitscan Library is free software: you can redistribute it and/or
modify it under the terms of the GNU Limited General Public License as
published by the Free Software Foundation, version 3.

The Bitscan Library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Limited General Public License version 3 for more details.

You should have received a copy of the GNU Limited General Public
License version 3 along with the Bitscan Library (filename
"COPYING"). If not, see http://www.gnu.org/licenses/ .
*/
extern const u8 bitscan_lsb_list_base[U8_SPAN];
extern const u8 bitscan_msb_list_base[U8_SPAN];

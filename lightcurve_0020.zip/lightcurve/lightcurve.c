/*
Lightcurve
Copyright 2017 Russell Leidich
http://agnentropy.blogspot.com

This collection of files constitutes the Lightcurve Library. (This is a
library in the abstact sense; it's not intended to compile to a ".lib"
file.)

The Lightcurve Library is free software: you can redistribute it and/or
modify it under the terms of the GNU Limited General Public License as
published by the Free Software Foundation, version 3.

The Lightcurve Library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Limited General Public License version 3 for more details.

You should have received a copy of the GNU Limited General Public
License version 3 along with the Lightcurve Library (filename
"COPYING"). If not, see http://www.gnu.org/licenses/ .
*/
/*
Light Curve ASCII-to-Binary Conversion Utility
*/
#include "flag.h"
#include "flag_ascii.h"
#include "flag_filesys.h"
#include "flag_fracterval_u64.h"
#include "flag_lightcurve.h"
#include <stdint.h>
#include <string.h>
#include "constant.h"
#include "debug.h"
#include "debug_xtrn.h"
#include "ascii_xtrn.h"
#include "filesys.h"
#include "filesys_xtrn.h"
#include "fracterval_u64.h"
#include "fracterval_u64_xtrn.h"

void
lightcurve_error_print(char *char_list_base){
  DEBUG_PRINT("ERROR: ");
  DEBUG_PRINT(char_list_base);
  DEBUG_PRINT(".\n");
  return;
}

void
lightcurve_out_of_memory_print(void){
  lightcurve_error_print("Out of memory");
  return;
}

void
lightcurve_parameter_error_print(char *char_list_base){
  DEBUG_PRINT("Invalid parameter: (");
  DEBUG_PRINT(char_list_base);
  DEBUG_PRINT("). For help, run without parameters.\n");
  return;
}

int
main(int argc, char *argv[]){
  ULONG arg_idx;
  u8 ascii;
  char *bin_filename_base;
  ULONG bin_filename_size;
  ULONG bin_u8_idx;
  u8 digit;
  u8 direction_status;
  u8 file_status;
  u8 filesys_status;
  u64 line_idx;
  u64 mask_fractoid;
  u64 mask_fractoid_old;
  u8 mask_size;
  u64 mask_u64;
  u64 mask_u64_span;
  u8 mono_count;
  char *mono_filename_base;
  ULONG mono_filename_size;
  u8 mono_status;
  ULONG mono_u8_idx;
  u8 *mono_u8_list_base;
  u8 output_phase;
  u8 overflow_status;
  u64 quantizer;
  u8 status;
  ULONG text_file_count;
  ULONG text_file_idx;
  ULONG text_file_size;
  ULONG text_file_size_max;
  char *text_filename_base;
  ULONG text_filename_char_idx;
  ULONG text_filename_char_idx_max;
  ULONG text_filename_char_idx_new;
  ULONG text_filename_idx;
  ULONG text_filename_idx_max;
  ULONG text_filename_size;
  ULONG text_filename_size_new;
  char *text_name_base;
  ULONG text_u8_idx;
  ULONG text_u8_idx_max;
  u8 *text_u8_list_base;

  bin_filename_base=NULL;
  mono_filename_base=NULL;
  mono_u8_list_base=NULL;
  output_phase=0;
  overflow_status=0;
  status=ascii_init(0, 0);
  status=(u8)(status|filesys_init(0, 0));
  text_filename_base=NULL;
  text_u8_list_base=NULL;
  do{
    if(status){
      lightcurve_error_print("Outdated source code");
      break;
    }
    status=1;
    if(argc!=5){
      DEBUG_PRINT("Lightcurve\nCopyright 2017 Russell Leidich\nhttp://agnentropy.blogspot.com\n");
      DEBUG_U32("build_id_in_hex", LIGHTCURVE_BUILD_ID);
      DEBUG_PRINT("ASCII-to-binary conversion utility for use with LcTools.\n\n");
      DEBUG_PRINT("Syntax:\n\n");
      DEBUG_PRINT("lightcurve quantizer textpath maskpath monopath\n\n");
      DEBUG_PRINT("(quantizer) is the number of divisions on the interval [0, 2] into which to\nseparate the normalized flux. Flux values outside this interval will be\nsaturated to zero or reported as errors, respectively. Zero will cause flux to\nbe converted to a series of 64-bit masks. Otherwise, the number of bytes in\neach mask will be the minimum possible number required to store one less than\nthis value.\n\n");
      DEBUG_PRINT("(textpath) is the file or folder to convert from text (.txt) to binary (.bin).\nIn the folder case, all symlinks will be ignored so that no subfolder will be\nprocessed more than once.\n\n");
      DEBUG_PRINT("(monopath) is the folder, different from the others, which will be overwritten\nwith a series of bytes, each giving the number of samples for which the flux is\nmonotonic.\n\n");
      DEBUG_PRINT("(maskpath) is the folder, different from the others, which will be overwritten\nwith the same filenames, but ending in \".bin\", each of which containing the\ncorresponding quantized masks.\n\n");
      break;
    }
    arg_idx=0;
    do{
      status=ascii_utf8_string_verify(argv[arg_idx]);
      if(status){
        lightcurve_error_print("One or more parameters is encoded using invalid UTF8");
        break;
      }
    }while((++arg_idx)<(ULONG)(argc));
    if(status){
      break;
    }
    status=ascii_decimal_to_u64_convert(argv[1], &quantizer, U32_SPAN);
    status=(u8)(status|(quantizer==1));
    if(status){
      lightcurve_parameter_error_print("quantizer");
      break;
    }
    mask_size=U64_SIZE;
    if(quantizer){
      mask_size=U8_SIZE;
      quantizer--;
      if(quantizer>>U8_BITS){
        mask_size++;
        if(quantizer>>U16_BITS){
          mask_size++;
          if(quantizer>>U24_BITS){
            mask_size++;
          }
        }
      }
      quantizer++;
    }
    bin_filename_size=strlen(argv[3]);
/*
Allocate enough space for the maximum path size that filesys_filename_list_get may append, plus one for a path separator, plus one for a terminating null.
*/
    bin_filename_size+=U16_MAX+2;
    bin_filename_base=filesys_char_list_malloc(bin_filename_size);
    bin_filename_size-=U16_MAX+2;
    status=!bin_filename_base;
    if(status){
      lightcurve_out_of_memory_print();
      break;
    }
    memcpy(bin_filename_base, argv[3], (size_t)(bin_filename_size));
    if(bin_filename_size&&!file_status){
      if(bin_filename_base[bin_filename_size-1]!=FILESYS_PATH_SEPARATOR){
        bin_filename_base[bin_filename_size]=FILESYS_PATH_SEPARATOR;
        bin_filename_size++;
      }
    }
    mono_filename_size=strlen(argv[4]);
    mono_filename_size+=U16_MAX+2;
    mono_filename_base=filesys_char_list_malloc(mono_filename_size);
    mono_filename_size-=U16_MAX+2;
    status=!mono_filename_base;
    if(status){
      lightcurve_out_of_memory_print();
      break;
    }
    memcpy(mono_filename_base, argv[4], (size_t)(mono_filename_size));
    if(mono_filename_size&&!file_status){
      if(mono_filename_base[mono_filename_size-1]!=FILESYS_PATH_SEPARATOR){
        mono_filename_base[mono_filename_size]=FILESYS_PATH_SEPARATOR;
        mono_filename_size++;
      }
    }
    text_name_base=argv[2];
    text_file_size_max=0;
    text_file_count=0;
    text_filename_size=U16_MAX;
    status=1;
    do{
      text_filename_char_idx_max=text_filename_size-1;
      text_filename_base=filesys_char_list_malloc(text_filename_char_idx_max);
      if(!text_filename_base){
        lightcurve_out_of_memory_print();
        break;
      }
      text_filename_size_new=text_filename_size;
      text_file_count=filesys_filename_list_get(&text_file_size_max, &file_status, text_filename_base, &text_filename_size_new, text_name_base);
      if(!text_file_count){
        lightcurve_error_print("(textpath) not found or inaccessible");
        break;
      }
      status=0;
      if(text_filename_size<text_filename_size_new){
        text_filename_base=filesys_free(text_filename_base);
        text_filename_size=text_filename_size_new;
        status=1;
      }
    }while(status);
    if(status){
      break;
    }
    text_u8_list_base=(u8 *)(DEBUG_MALLOC_PARANOID(text_file_size_max));
    status=!text_u8_list_base;
    if(status){
      lightcurve_out_of_memory_print();
      break;
    }
    mono_u8_list_base=(u8 *)(DEBUG_MALLOC_PARANOID(text_file_size_max));
    status=!mono_u8_list_base;
    if(status){
      lightcurve_out_of_memory_print();
      break;
    }
    text_filename_char_idx=0;
    text_file_idx=0;
    do{
      filesys_status=FILESYS_STATUS_CALLER_CUSTOM;
      text_file_size=text_file_size_max;
      text_filename_char_idx_new=text_filename_char_idx;
      text_filename_idx_max=(ULONG)(strlen(&text_filename_base[text_filename_char_idx]));
      text_filename_idx_max+=text_filename_char_idx;
      if(3<(text_filename_idx_max-text_filename_char_idx)){
        if(text_filename_base[text_filename_idx_max-4]=='.'){
          if(text_filename_base[text_filename_idx_max-3]=='t'){
            if(text_filename_base[text_filename_idx_max-2]=='x'){
              if(text_filename_base[text_filename_idx_max-1]=='t'){
                filesys_status=filesys_file_read_next(&text_file_size, &text_filename_char_idx_new, text_filename_base, text_u8_list_base);
              }
            }
          }
        }
      }
      line_idx=1;
      status=!!filesys_status;
      if(!status){
        bin_u8_idx=0;
        mono_u8_idx=0;
        filesys_status=FILESYS_STATUS_CALLER_CUSTOM2;
        status=1;
        if(text_file_size){
          text_u8_idx=0;
          text_u8_idx_max=(ULONG)(text_file_size-1);
          status=1;
          do{
            ascii=text_u8_list_base[text_u8_idx];
            text_u8_idx++;
            if(ascii==0xD){
              status=0;
              break;
            }
          }while(text_u8_idx<=text_u8_idx_max);
          status=(u8)(status|(text_u8_idx_max<text_u8_idx));
          if(status){
            break;
          }
          ascii=text_u8_list_base[text_u8_idx];
          text_u8_idx++;
          if(ascii!=0xA){
            status=1;
          }
          status=(u8)(status|(text_u8_idx_max<text_u8_idx));
          if(status){
            break;
          }
          direction_status=0;
          line_idx++;
          mono_count=U8_MAX;
          mono_status=1;
          mask_fractoid_old=0;
          do{
            status=1;
            do{
              ascii=text_u8_list_base[text_u8_idx];
              text_u8_idx++;
              if(ascii==','){
                status=0;
                break;
              }
              if(ascii<' '){
                break;
              }
            }while(text_u8_idx<=text_u8_idx_max);
            status=(u8)(status|(text_u8_idx_max<text_u8_idx));
            if(status){
              break;
            }
            ascii=text_u8_list_base[text_u8_idx];
            ascii=(u8)(ascii-'0');
            digit=1;
            text_u8_idx++;
            if(!ascii){
              digit=0;
            }else if(1<ascii){
              status=1;
            }
            status=(u8)(status|(text_u8_idx_max<text_u8_idx));
            if(status){
              break;
            }
            ascii=text_u8_list_base[text_u8_idx];
            text_u8_idx++;
            if(ascii!='.'){
              status=1;
              if(ascii==0xD){
                status=0;
                text_u8_idx--;
              }
            }
            status=(u8)(status|(text_u8_idx_max<text_u8_idx));
            if(status){
              break;
            }
            mask_u64=digit;
            mask_u64_span=2;
            status=1;
            do{
              ascii=text_u8_list_base[text_u8_idx];
              text_u8_idx++;
              if(ascii==0xD){
                status=0;
                break;
              }
              digit=(u8)(ascii-'0');
              if(9<digit){
                break;
              }
              if(((U64_MAX-9)/10)<mask_u64_span){
                break;
              }
              mask_u64=(mask_u64*10)+digit;
              mask_u64_span*=10;
            }while(text_u8_idx<=text_u8_idx_max);
            status=(u8)(status|(text_u8_idx_max<text_u8_idx));
            if(status){
              break;
            }
            ascii=text_u8_list_base[text_u8_idx];
            text_u8_idx++;
            if(ascii!=0xA){
             status=1;
            }
            FTD64_RATIO_U64_SATURATE(mask_fractoid, mask_u64, mask_u64_span, overflow_status);
            mono_status=1;
            if(direction_status&(mask_fractoid_old<mask_fractoid)){
              direction_status=0;
              mono_status=0;
            }else if((!direction_status)&(mask_fractoid<mask_fractoid_old)){
              direction_status=1;
              mono_status=0;
            }
            mono_count=(u8)(mono_count+mono_status);
            if((!mono_status)||(mono_count==U8_MAX)){
              mono_u8_list_base[mono_u8_idx]=mono_count;
              mono_count=0;
              mono_u8_idx++;
            }
            mask_fractoid_old=mask_fractoid;
            mask_u64=mask_fractoid;
            if(quantizer){
              FTD64_SCALE_U64(mask_u64, mask_fractoid, quantizer);
            }
            memcpy(&text_u8_list_base[bin_u8_idx], &mask_u64, (size_t)(mask_size));
            bin_u8_idx+=mask_size;
            line_idx++;
          }while(text_u8_idx<=text_u8_idx_max);
        }
        if(!status){
          text_filename_base[text_filename_idx_max-3]='b';
          text_filename_base[text_filename_idx_max-2]='i';
          text_filename_base[text_filename_idx_max-1]='n';
          text_filename_idx=text_filename_idx_max-4;
          while(text_filename_idx){
            ascii=(u8)(text_filename_base[text_filename_idx-1]);
            if(ascii==FILESYS_PATH_SEPARATOR){
              break;
            }
            text_filename_idx--;
          }
          text_filename_size=text_filename_idx_max-text_filename_idx+1;
          memcpy(&bin_filename_base[bin_filename_size], &text_filename_base[text_filename_idx], (size_t)(text_filename_size));
          bin_filename_base[bin_filename_size+text_filename_size]=0;
          filesys_status=filesys_file_write(bin_u8_idx, bin_filename_base, text_u8_list_base);
          output_phase=0;
          if(!filesys_status){
            memcpy(&mono_filename_base[mono_filename_size], &text_filename_base[text_filename_idx], (size_t)(text_filename_size));
            mono_filename_base[mono_filename_size+text_filename_size]=0;
            filesys_status=filesys_file_write(mono_u8_idx, mono_filename_base, mono_u8_list_base);
            output_phase=1;
          }
          status=!!filesys_status;
        }
      }
      if(status){
        if(filesys_status!=FILESYS_STATUS_WRITE_FAIL){
          DEBUG_PRINT(&text_filename_base[text_filename_char_idx]);
        }else{
          if(!output_phase){
            DEBUG_PRINT(bin_filename_base);
          }else{
            DEBUG_PRINT(mono_filename_base);
          }
        }
        DEBUG_PRINT("\n");
        switch(filesys_status){
        case FILESYS_STATUS_NOT_FOUND:
          lightcurve_error_print("Not found");
          break;
        case FILESYS_STATUS_TOO_BIG:
          lightcurve_error_print("Too big to fit in memory");
          break;
        case FILESYS_STATUS_READ_FAIL:
          lightcurve_error_print("Read failed");
          break;
        case FILESYS_STATUS_WRITE_FAIL:
          lightcurve_error_print("Write failed");
          break;
        case FILESYS_STATUS_SIZE_CHANGED:
          lightcurve_error_print("File size changed during read");
          break;
        case FILESYS_STATUS_CALLER_CUSTOM:
          lightcurve_error_print("File ignored because it doesn't end in \".txt\"");
          break;
        case FILESYS_STATUS_CALLER_CUSTOM2:
          lightcurve_error_print("File rejected. Most likely this is because it contains a relative flux\nvalue of at least 2, on the line number below. But it could also be due to\ninvalid number formatting");
          DEBUG_U64("line_number_in_hex", line_idx);
          break;
        default:
          lightcurve_error_print("Internal error. Please report");
        }
      }
      text_filename_char_idx=text_filename_char_idx_new;
      text_file_idx++;
      status=0;
    }while(text_file_idx!=text_file_count);
  }while(0);
  DEBUG_FREE_PARANOID(text_u8_list_base);
  filesys_free(text_filename_base);
  DEBUG_FREE_PARANOID(mono_u8_list_base);
  filesys_free(mono_filename_base);
  filesys_free(bin_filename_base);
  DEBUG_ALLOCATION_CHECK();
  return status;
}

/*
Lightcurve
Copyright 2017 Russell Leidich
http://agnentropy.blogspot.com

This collection of files constitutes the Lightcurve Library. (This is a
library in the abstact sense; it's not intended to compile to a ".lib"
file.)

The Lightcurve Library is free software: you can redistribute it and/or
modify it under the terms of the GNU Limited General Public License as
published by the Free Software Foundation, version 3.

The Lightcurve Library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Limited General Public License version 3 for more details.

You should have received a copy of the GNU Limited General Public
License version 3 along with the Lightcurve Library (filename
"COPYING"). If not, see http://www.gnu.org/licenses/ .
*/
/*
Light Curve Scanner for Dips and Flares
*/
#include "flag.h"
#include "flag_ascii.h"
#include "flag_filesys.h"
#include "flag_fracterval_u128.h"
#include "flag_fracterval_u64.h"
#include "flag_spikescan.h"
#include <stdint.h>
#include <string.h>
#include "constant.h"
#include "debug.h"
#include "debug_xtrn.h"
#include "ascii_xtrn.h"
#include "filesys.h"
#include "filesys_xtrn.h"
#include "fracterval_u128.h"
#include "fracterval_u128_xtrn.h"
#include "fracterval_u64.h"
#include "fracterval_u64_xtrn.h"

void
spikescan_error_print(char *char_list_base){
  DEBUG_PRINT("ERROR: ");
  DEBUG_PRINT(char_list_base);
  DEBUG_PRINT(".\n");
  return;
}

void
spikescan_out_of_memory_print(void){
  spikescan_error_print("Out of memory");
  return;
}

void
spikescan_parameter_error_print(char *char_list_base){
  DEBUG_PRINT("Invalid parameter: (");
  DEBUG_PRINT(char_list_base);
  DEBUG_PRINT("). For help, run without parameters.\n");
  return;
}

int
main(int argc, char *argv[]){
  ULONG arg_idx;
  u64 delta;
  fru128 delta_fru128;
  u64 delta_squared;
  u128 delta_squared_sum;
  u8 file_status;
  u8 filesys_status;
  u8 flare_status;
  ULONG in_file_count;
  ULONG in_file_idx;
  ULONG in_file_size;
  ULONG in_file_size_max;
  char *in_filename_base;
  ULONG in_filename_char_idx;
  ULONG in_filename_char_idx_max;
  ULONG in_filename_char_idx_new;
  ULONG in_filename_size;
  ULONG in_filename_size_new;
  char *in_name_base;
  ULONG in_u8_idx;
  ULONG in_u8_idx_max;
  u8 *in_u8_list_base;
  u8 integer_bit_count;
  ULONG mask_count;
  u128 mask_sum;
  u64 mask_u64;
  u64 mask_u64_max;
  u64 mask_u64_min;
  u64 mean;
  u8 overflow_status;
  u64 parameter;
  fru128 sigma;
  fru128 sigma_ratio;
  u128 sigma_ratio_mean;
  u64 sigma_ratio_mean_u64;
  u8 status;

  overflow_status=0;
  status=ascii_init(0, 0);
  status=(u8)(status|filesys_init(0, 0));
  in_filename_base=NULL;
  in_u8_list_base=NULL;
  do{
    if(status){
      spikescan_error_print("Outdated source code");
      break;
    }
    status=1;
    if(argc!=3){
      DEBUG_PRINT("Spike Scan\nCopyright 2017 Russell Leidich\nhttp://agnentropy.blogspot.com\n");
      DEBUG_U32("build_id_in_hex", SPIKESCAN_BUILD_ID);
      DEBUG_PRINT("Dip and flare finder for use with LcTools.\n\n");
      DEBUG_PRINT("Syntax:\n\n");
      DEBUG_PRINT("spikescan mode binpath\n\n");
      DEBUG_PRINT("(mode) controls behavior:\n\n  bit 0: (flare) is zero to scan for dips, else\n  one to find flares.\n\n");
      DEBUG_PRINT("(binpath) is the file or folder to scan for dips or flares. In the folder case,\nall symlinks will be ignored so that no subfolder will be processed more than\nonce. All files must consist of 64-bit normalized flux values as produced by\nlightcurve with a quantizer of zero.\n\n");
      break;
    }
    arg_idx=0;
    do{
      status=ascii_utf8_string_verify(argv[arg_idx]);
      if(status){
        spikescan_error_print("One or more parameters is encoded using invalid UTF8");
        break;
      }
    }while((++arg_idx)<(ULONG)(argc));
    if(status){
      break;
    }
    status=ascii_hex_to_u64_convert(argv[1], &parameter, 1);
    if(status){
      spikescan_parameter_error_print("mode");
      break;
    }
    flare_status=(u8)(parameter);
    in_name_base=argv[2];
    in_file_size_max=0;
    in_file_count=0;
    in_filename_size=U16_MAX;
    status=1;
    do{
      in_filename_char_idx_max=in_filename_size-1;
      in_filename_base=filesys_char_list_malloc(in_filename_char_idx_max);
      if(!in_filename_base){
        spikescan_out_of_memory_print();
        break;
      }
      in_filename_size_new=in_filename_size;
      in_file_count=filesys_filename_list_get(&in_file_size_max, &file_status, in_filename_base, &in_filename_size_new, in_name_base);
      if(!in_file_count){
        spikescan_error_print("(binpath) not found or inaccessible");
        break;
      }
      status=0;
      if(in_filename_size<in_filename_size_new){
        in_filename_base=filesys_free(in_filename_base);
        in_filename_size=in_filename_size_new;
        status=1;
      }
    }while(status);
    if(status){
      break;
    }
    in_u8_list_base=(u8 *)(DEBUG_MALLOC_PARANOID(in_file_size_max));
    status=!in_u8_list_base;
    if(status){
      spikescan_out_of_memory_print();
      break;
    }
    in_filename_char_idx=0;
    in_file_idx=0;
    mask_u64_max=0;
    mask_u64_min=0;
    do{
      in_file_size=in_file_size_max;
      in_filename_char_idx_new=in_filename_char_idx;
      filesys_status=filesys_file_read_next(&in_file_size, &in_filename_char_idx_new, in_filename_base, in_u8_list_base);
      if((!in_file_size)||(in_file_size&U64_BYTE_MAX)){
        filesys_status=FILESYS_STATUS_CALLER_CUSTOM;
      }
      status=!!filesys_status;
      if(!status){
        in_u8_idx=0;
        in_u8_idx_max=(ULONG)(in_file_size-1);
        mask_count=in_file_size>>U64_SIZE_LOG2;
        U128_SET_ZERO(mask_sum);
        mask_u64_max=0;
        mask_u64_min=~mask_u64_max;
        do{
          memcpy(&mask_u64, &in_u8_list_base[in_u8_idx], (size_t)(U64_SIZE));
          in_u8_idx+=U64_SIZE;
          U128_ADD_U64_LO_SELF(mask_sum, mask_u64);
          mask_u64_max=MAX(mask_u64, mask_u64_max);
          mask_u64_min=MIN(mask_u64, mask_u64_min);
        }while(in_u8_idx<=in_u8_idx_max);
        U128_DIVIDE_U64_TO_U64_SATURATE(mean, mask_sum, mask_count, overflow_status);
        delta_squared_sum=0;
        in_u8_idx=0;
        mask_count=0;
        do{
          memcpy(&mask_u64, &in_u8_list_base[in_u8_idx], (size_t)(U64_SIZE));
          in_u8_idx+=U64_SIZE;
          if(!flare_status){
            if(mask_u64<=mean){
              delta=mean-mask_u64;
              mask_count++;
              FTD64_SCALE_U64(delta_squared, delta, delta);
              U128_ADD_U64_LO_SELF(delta_squared_sum, delta_squared);
            }
          }else{
            if(mean<=mask_u64){
              delta=mask_u64-mean;
              mask_count++;
              FTD64_SCALE_U64(delta_squared, delta, delta);
              U128_ADD_U64_LO_SELF(delta_squared_sum, delta_squared);
            }
          }
        }while(in_u8_idx<=in_u8_idx_max);
        U128_DIVIDE_U64_TO_U128_SATURATE_SELF(delta_squared_sum, mask_count, overflow_status);
        FRU128_ROOT_FRACTOID_U128(sigma, delta_squared_sum);
        FRU128_SHIFT_LEFT_SELF(sigma, U32_BITS, overflow_status);
        if(!flare_status){
          delta=mean-mask_u64_min;
        }else{
          delta=mask_u64_max-mean;
        }
        FRU128_FROM_FTD64_HI(delta_fru128, delta);
        integer_bit_count=0;
        while(U128_IS_LESS_EQUAL(sigma.b, delta_fru128.a)&&(integer_bit_count<=U8_BIT_MAX)){
          FRU128_SHIFT_RIGHT_SELF(delta_fru128, 1);
          integer_bit_count++;
        }
        FRU128_DIVIDE_FRU128(sigma_ratio, delta_fru128, sigma, overflow_status);
        integer_bit_count=(u8)(U8_BITS-integer_bit_count);
        FRU128_SHIFT_RIGHT_SELF(sigma_ratio, integer_bit_count);
        FRU128_MEAN_TO_FTD128(sigma_ratio_mean, sigma_ratio);
        U128_TO_U64_HI(sigma_ratio_mean_u64, sigma_ratio_mean);
        DEBUG_U64("", sigma_ratio_mean_u64);
        DEBUG_PRINT(" ");
        DEBUG_PRINT(&in_filename_base[in_filename_char_idx]);
        DEBUG_PRINT("\n");
      }else{
        DEBUG_PRINT(&in_filename_base[in_filename_char_idx]);
        DEBUG_PRINT("\n");
        switch(filesys_status){
        case FILESYS_STATUS_NOT_FOUND:
          spikescan_error_print("Not found");
          break;
        case FILESYS_STATUS_TOO_BIG:
          spikescan_error_print("Too big to fit in memory");
          break;
        case FILESYS_STATUS_READ_FAIL:
          spikescan_error_print("Read failed");
          break;
        case FILESYS_STATUS_SIZE_CHANGED:
          spikescan_error_print("File size changed during read");
          break;
        case FILESYS_STATUS_CALLER_CUSTOM:
          spikescan_error_print("File size not a nonzero multiple of (granularity+1)");
          break;
        default:
          spikescan_error_print("Internal error. Please report");
        }
      }
      in_filename_char_idx=in_filename_char_idx_new;
      in_file_idx++;
      status=0;
    }while(in_file_idx!=in_file_count);
    status=1;
    if(overflow_status){
      spikescan_error_print("Fracterval precision was exhausted. Please report");
      break;
    }
    status=0;
  }while(0);
  DEBUG_FREE_PARANOID(in_u8_list_base);
  filesys_free(in_filename_base);
  DEBUG_ALLOCATION_CHECK();
  return status;
}
